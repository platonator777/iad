# %% [markdown]
# # Два датасета для регрессии: проверка пригодности и модели
#
# Проверяем два задания на реальных данных: две группы с собственными
# регрессиями и разным разбросом; нелинейную связь, которую можно линеаризовать.
# Результаты показаны графиками; пояснения и формулы находятся в Markdown.
#
# Здесь различаем **множественную регрессию** (несколько признаков X) и
# **смесь регрессий** (несколько групп с отдельными уравнениями). Первое
# задание по описанию требует именно смеси; для пингвинов рассмотрены оба случая.
# «Скрыть ответы» означает убрать метки вида, сохранив измерения X и y:
# без наблюдаемой зависимой величины регрессию обучить нельзя.

# %%
# Библиотеки и воспроизводимость
from pathlib import Path
import json

import matplotlib
if "__file__" in globals():
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from scipy.stats import chi2, levene, multivariate_normal, t
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.mixture import GaussianMixture
from sklearn.model_selection import KFold, train_test_split

BASE = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
OUT = BASE / "outputs"
FIG = OUT / "figures"
FIG.mkdir(parents=True, exist_ok=True)
SEED = 42
COLORS = {"Adelie": "#2769A3", "Gentoo": "#C77824", "Chinstrap": "#77549B"}
BLUE, ORANGE, GREEN, RED = "#2769A3", "#C77824", "#007F73", "#C94A3D"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.axisbelow": True, "grid.alpha": .25,
})
results = {}


def figure(fig, name):
    fig.savefig(FIG / name, dpi=150, bbox_inches="tight")
    if "__file__" not in globals():
        plt.show()
    plt.close(fig)


def design(x):
    x = np.asarray(x, dtype=float)
    if x.ndim == 1:
        x = x[:, None]
    return np.column_stack([np.ones(len(x)), x])


def ols(x, y):
    X, y = design(x), np.asarray(y, dtype=float)
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    error = y - X @ beta
    df = len(y) - np.linalg.matrix_rank(X)
    inv = np.linalg.pinv(X.T @ X)
    h = np.einsum("ij,jk,ik->i", X, inv, X)
    mse = error @ error / df
    adjusted = error / np.maximum(1 - h, 1e-9)
    cov = inv @ (X.T @ ((adjusted**2)[:, None] * X)) @ inv
    return {"beta": beta, "cov": cov, "classical_cov": mse * inv,
            "mse": mse, "df": df, "error": error, "n": len(y),
            "r2": r2_score(y, X @ beta)}


def predict(fit, x):
    return design(x) @ fit["beta"]


def interval(fit, x, observation=False):
    X = design(x)
    covariance = fit["classical_cov"] if observation else fit["cov"]
    variance = np.einsum("ij,jk,ik->i", X, covariance, X)
    if observation:
        variance += fit["mse"]
    half = t.ppf(.975, fit["df"]) * np.sqrt(np.maximum(variance, 0))
    center = X @ fit["beta"]
    return center - half, center + half


def coefficient_ci(fit):
    half = t.ppf(.975, fit["df"]) * np.sqrt(np.maximum(np.diag(fit["cov"]), 0))
    return np.column_stack([fit["beta"] - half, fit["beta"] + half])

# %% [markdown]
# ## 1. Palmer Penguins: что измерено и какие группы сравниваем
#
# [Авторы набора Palmer Penguins](https://allisonhorst.github.io/palmerpenguins/)
# публикуют измерения 344 пингвинов трёх видов с островов архипелага Палмера
# за 2007–2009 годы. Размеры клюва и ласты даны в миллиметрах, масса — в граммах.
# Локальный `data/penguins.csv` позволяет выполнить отчёт без доступа к сети.
#
# Для двух регрессий используем Adelie и Gentoo. Chinstrap полностью оставляем
# для проверки объектов вне этих двух групп. Это не обещает распознать любой
# новый вид: чужой объект с подходящими измерениями может быть принят.
# Пропуски в геометрии или массе удаляем; пропуск пола этому анализу не мешает.

# %%
# Качество и охват данных пингвинов
p_raw = pd.read_csv(BASE / "data/penguins.csv")
geometry = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm"]
penguins = p_raw.dropna(subset=geometry + ["body_mass_g"]).copy()
assert not penguins.duplicated().any()
assert penguins[geometry + ["body_mass_g"]].gt(0).all().all()
species_order = ["Adelie", "Gentoo", "Chinstrap"]
fig, axes = plt.subplots(1, 2, figsize=(11, 3.8), layout="constrained")
counts = penguins.species.value_counts().reindex(species_order)
bars = axes[0].bar(counts.index, counts, color=[COLORS[s] for s in counts.index])
axes[0].bar_label(bars)
axes[0].set(title=f"Остаётся {len(penguins)} из {len(p_raw)} наблюдений", ylabel="Число пингвинов", ylim=(0, 175))
missing = p_raw[geometry + ["body_mass_g", "sex"]].isna().sum()
bars = axes[1].barh(["Длина клюва", "Глубина клюва", "Длина ласты", "Масса", "Пол"], missing, color=BLUE)
axes[1].bar_label(bars, padding=3)
axes[1].set(title="Пропуски по признакам", xlabel="Число строк", xlim=(0, missing.max() + 3))
figure(fig, "01_penguins_quality.png")
results["penguin_counts"] = counts.to_dict()

# %% [markdown]
# ### 1.1. Есть ли связь глубины и длины клюва у каждого вида?
#
# Для каждого вида оцениваем d = a + bL + ε. Узкая полоса — 95% ДИ среднего
# E[d|L], широкая — приближённый 95% прогнозный интервал отдельного пингвина.
# Для ДИ коэффициентов и среднего используем HC3, устойчивую к неодинаковой
# дисперсии; для прогнозного интервала предполагаем нормальные остатки с
# постоянной дисперсией **внутри вида**. Это разные интервалы.

# %%
# Регрессии клюва и интервалы наклонов
bill_models = {}
fig, axes = plt.subplots(1, 4, figsize=(16, 4.3), layout="constrained", gridspec_kw={"width_ratios": [1, 1, 1, .95]})
for k, species in enumerate(species_order):
    part = penguins.loc[penguins.species.eq(species)]
    fit = ols(part.bill_length_mm, part.bill_depth_mm)
    bill_models[species] = fit
    grid = np.linspace(part.bill_length_mm.min(), part.bill_length_mm.max(), 160)
    mean_lo, mean_hi = interval(fit, grid)
    obs_lo, obs_hi = interval(fit, grid, observation=True)
    ax = axes[k]
    ax.fill_between(grid, obs_lo, obs_hi, color=COLORS[species], alpha=.10, label="95% прогнозный интервал")
    ax.fill_between(grid, mean_lo, mean_hi, color=COLORS[species], alpha=.30, label="95% ДИ среднего (HC3)")
    ax.scatter(part.bill_length_mm, part.bill_depth_mm, color=COLORS[species], alpha=.45, s=15)
    ax.plot(grid, predict(fit, grid), color=COLORS[species], lw=2)
    ax.set(title=f"{species}: n={len(part)}, R²={fit['r2']:.2f}", xlabel="Длина клюва, мм", ylim=(12, 23), ylabel="Глубина клюва, мм" if k == 0 else "")
    ax.grid()
    bounds = coefficient_ci(fit)[1]
    axes[3].hlines(k, *bounds, color=COLORS[species], lw=3)
    axes[3].scatter(fit["beta"][1], k, color=COLORS[species])
    results[f"bill_{species}"] = {"beta": fit["beta"].tolist(), "slope_ci": bounds.tolist(), "r2": fit["r2"], "sigma": np.sqrt(fit["mse"])}
axes[0].legend(fontsize=7, loc="upper left")
axes[3].axvline(0, color=".4", ls="--")
axes[3].set(title="Наклон b и 95% ДИ", yticks=range(3), yticklabels=species_order, xlabel="мм глубины на 1 мм длины", ylim=(-.7, 2.7))
axes[3].grid(axis="x")
figure(fig, "02_penguins_bill_regressions.png")

# %% [markdown]
# **Уравнения по всем доступным наблюдениям вида** (L и d в мм):
#
# - **Adelie:** $\hat d=11.409+0.179L$, остаточное $s=1.123$ мм, $R^2=0.153$; 95% ДИ наклона [0.107; 0.251].
# - **Gentoo:** $\hat d=5.251+0.205L$, остаточное $s=0.754$ мм, $R^2=0.414$; 95% ДИ наклона [0.164; 0.246].
# - **Chinstrap:** $\hat d=7.569+0.222L$, остаточное $s=0.866$ мм, $R^2=0.427$; 95% ДИ наклона [0.134; 0.311].
#
# Для отдельного наблюдения при нормальном шуме с постоянной дисперсией внутри вида:
#
# $$d_{new}(L)\approx\hat d(L)\pm t_{n-2;0.975}\,s\sqrt{1+\frac1n+\frac{(L-\bar L)^2}{\sum_i(L_i-\bar L)^2}}.$$
#
# Слагаемое 1 отвечает за естественный разброс отдельного пингвина. У доверительного интервала среднего его нет; HC3 дополнительно заменяет обычную оценку дисперсии среднего устойчивой. На краях диапазона неопределённость растёт.
#
# Все три интервала наклона исключают ноль: на этих данных нельзя объявить
# зависимость одного из видов «случайностью». При этом умеренное R² и широкие
# прогнозные интервалы означают, что длина объясняет лишь часть разброса.
# Вывод об отсутствии связи потребовал бы интервала, совместимого с нулём;
# отсутствие статистической значимости само по себе не доказывало бы равенство нулю.

# %% [markdown]
# ### 1.2. Масса как функция нескольких геометрических параметров
#
# Проверяем предложение преподавателя: m = a + bF + cL + dD + ε, где F —
# длина ласты, L — длина, D — глубина клюва. Слева показаны простые связи
# массы с ластой; справа — частные коэффициенты **множественной** регрессии
# по каждому виду. Для сравнения коэффициентов признаки справа стандартизованы
# внутри вида, поэтому единица оси — граммы массы на одно SD признака.

# %%
# Геометрия и масса: простая связь и частные эффекты
fig, axes = plt.subplots(1, 2, figsize=(13, 4.6), layout="constrained")
mass_models = {}
feature_names = ["Длина ласты", "Длина клюва", "Глубина клюва"]
for k, species in enumerate(species_order):
    part = penguins.loc[penguins.species.eq(species)]
    axes[0].scatter(part.flipper_length_mm, part.body_mass_g, color=COLORS[species], alpha=.4, s=16, label=species)
    simple = ols(part.flipper_length_mm, part.body_mass_g)
    grid = np.linspace(part.flipper_length_mm.min(), part.flipper_length_mm.max(), 100)
    lo, hi = interval(simple, grid)
    axes[0].plot(grid, predict(simple, grid), color=COLORS[species])
    axes[0].fill_between(grid, lo, hi, color=COLORS[species], alpha=.15)
    mass_x = part[["flipper_length_mm", "bill_length_mm", "bill_depth_mm"]]
    fit = ols(mass_x, part.body_mass_g)
    mass_models[species] = fit
    standardized = ols((mass_x - mass_x.mean()) / mass_x.std(ddof=0), part.body_mass_g)
    limits = coefficient_ci(standardized)
    for j in range(3):
        y = j + (k - 1) * .2
        axes[1].hlines(y, *limits[j + 1], color=COLORS[species], lw=2)
        axes[1].scatter(standardized["beta"][j + 1], y, color=COLORS[species], s=28, label=species if j == 0 else None)
    results[f"mass_{species}"] = {"beta": fit["beta"].tolist(), "r2": fit["r2"], "sigma": np.sqrt(fit["mse"]), "partial_ci": coefficient_ci(fit).tolist()}
axes[0].set(title="Масса и длина ласты: простые регрессии и 95% ДИ", xlabel="Длина ласты, мм", ylabel="Масса, г")
axes[0].legend(); axes[0].grid()
axes[1].axvline(0, color=".4", ls="--")
axes[1].set(title="При учёте остальных размеров: коэффициенты и 95% ДИ", yticks=range(3), yticklabels=feature_names, xlabel="г на одно SD размера внутри вида")
axes[1].legend(loc="upper center", bbox_to_anchor=(.5, -.18), ncol=3, fontsize=8)
axes[1].grid(axis="x")
figure(fig, "03_penguins_mass_geometry.png")

# %% [markdown]
# **Множественные уравнения массы**, F, L, D в мм, m в граммах:
#
# - **Adelie:** $\hat m=-4341.3+17.42F+55.37L+140.89D$; $R^2=0.508$, остаточное $s=324.9$ г.
# - **Gentoo:** $\hat m=-4426.5+22.12F+41.23L+182.81D$; $R^2=0.625$, остаточное $s=312.8$ г.
# - **Chinstrap:** $\hat m=-3157.5+22.58F+16.04L+91.51D$; $R^2=0.504$, остаточное $s=277.0$ г.
#
# У Chinstrap 95% ДИ частного коэффициента длины клюва [-13.53; 45.61] г/мм, глубины — [-6.83; 189.86] г/мм: оба включают ноль. Поэтому именно здесь есть пример неопределённого добавочного вклада клюва после учёта других размеров. Длина ласты имеет положительный частный коэффициент у всех трёх видов.
#
# Это описательные уравнения в пределах измеренных размеров, а не причинные
# эффекты. Сравнивать коэффициенты в исходных мм без учёта масштаба признаков
# неудобно, поэтому на графике показана стандартизованная версия. Интервал,
# пересекающий ноль, означает неопределённость **добавочного** вклада при
# фиксированных остальных размерах, а не отсутствие простой корреляции с массой.

# %% [markdown]
# ### 1.3. Одна регрессия, две регрессии и скрытые метки вида
#
# Теперь возвращаемся к глубине клюва как y и длине как x — здесь особенно
# наглядны две полосы и разный разброс. Adelie/Gentoo делим на обучение 70%
# и тест 30% с сохранением долей видов. Chinstrap в обучение не попадает.
#
# Сравниваем общую прямую, две прямые с известным видом и модель без меток вида.
# Последняя — смесь двух двумерных нормальных распределений с полной
# ковариацией, обучаемая EM. Условное распределение каждого компонента —
# собственная линейная регрессия d|L,k ~ N(a_k+b_k L, σ²_k).
# Вероятность компонента зависит от L, а принадлежность измеренного объекта —
# от плотности пары (L,d), а не только от расстояния до центра.
#
# Метки вида нужны только для разделения и последующей оценки. При подаче
# данных в EM колонка species отсутствует. Для прогноза глубины на тесте
# модель получает только длину; выбирать регрессию по известной тестовой
# глубине и затем считать ошибку прогноза было бы некорректно.

# %%
# Обучение одной и двух регрессий, EM без меток вида
known = penguins.loc[penguins.species.isin(["Adelie", "Gentoo"])].copy()
p_train, p_test = train_test_split(known, test_size=.30, stratify=known.species, random_state=SEED)
p_other = penguins.loc[penguins.species.eq("Chinstrap")]
pooled = ols(p_train.bill_length_mm, p_train.bill_depth_mm)
separate = {s: ols(d.bill_length_mm, d.bill_depth_mm) for s, d in p_train.groupby("species")}
pair = p_train[["bill_length_mm", "bill_depth_mm"]].to_numpy()
pair_mean, pair_sd = pair.mean(axis=0), pair.std(axis=0)
mixture = GaussianMixture(n_components=2, covariance_type="full", n_init=20, reg_covar=1e-5, random_state=SEED)
mixture.fit((pair - pair_mean) / pair_sd)  # Нет species и нет меток теста.
assert mixture.converged_
# Имена цветов присваиваем только после обучения, по положению полос.
component_order = np.argsort(mixture.means_[:, 1])[::-1]
components = {}
for species, k in zip(["Adelie", "Gentoo"], component_order):
    mu = mixture.means_[k] * pair_sd + pair_mean
    covariance = mixture.covariances_[k] * np.outer(pair_sd, pair_sd)
    slope = covariance[0, 1] / covariance[0, 0]
    components[species] = {
        "a": mu[1] - slope * mu[0], "b": slope,
        "sigma": np.sqrt(covariance[1, 1] - covariance[0, 1]**2 / covariance[0, 0]),
        "mx": mu[0], "vx": covariance[0, 0], "weight": mixture.weights_[k],
    }


def mixture_prediction(x):
    x = np.asarray(x)
    logs = np.column_stack([
        np.log(c["weight"]) - .5 * (np.log(2 * np.pi * c["vx"]) + (x - c["mx"])**2 / c["vx"])
        for c in components.values()
    ])
    weights = np.exp(logs - logsumexp(logs, axis=1, keepdims=True))
    means = np.column_stack([c["a"] + c["b"] * x for c in components.values()])
    return (weights * means).sum(axis=1)


pred_pooled = predict(pooled, p_test.bill_length_mm)
pred_oracle = np.array([predict(separate[row.species], [row.bill_length_mm])[0] for row in p_test.itertuples()])
pred_em = mixture_prediction(p_test.bill_length_mm)
predictions = {"Одна прямая": pred_pooled, "Две, вид известен": pred_oracle, "Смесь, вид скрыт": pred_em}
results["penguin_test"] = {name: {"mae": mean_absolute_error(p_test.bill_depth_mm, pred), "rmse": np.sqrt(mean_squared_error(p_test.bill_depth_mm, pred))} for name, pred in predictions.items()}
results["mixture"] = components
results["pooled_slope"] = pooled["beta"][1]
variance_p = levene(separate["Adelie"]["error"], separate["Gentoo"]["error"], center="median").pvalue
results["penguin_variance"] = {"p": variance_p, "sigmas": {s: np.sqrt(f["mse"]) for s, f in separate.items()}}
fig, axes = plt.subplots(1, 3, figsize=(15, 4.5), layout="constrained")
for ax in axes[:2]:
    for s, d in p_train.groupby("species"):
        ax.scatter(d.bill_length_mm, d.bill_depth_mm, s=15, color=COLORS[s], alpha=.35)
    ax.set(xlabel="Длина клюва, мм", ylabel="Глубина клюва, мм", ylim=(11.5, 23))
    ax.grid()
grid = np.linspace(p_train.bill_length_mm.min(), p_train.bill_length_mm.max(), 220)
axes[0].plot(grid, predict(pooled, grid), color=RED, ls="--", label="Общая прямая")
for s, fit in separate.items():
    part = p_train.loc[p_train.species.eq(s)]
    g = np.linspace(part.bill_length_mm.min(), part.bill_length_mm.max(), 130)
    low, high = interval(fit, g, observation=True)
    axes[0].fill_between(g, low, high, color=COLORS[s], alpha=.15)
    axes[0].plot(g, predict(fit, g), color=COLORS[s], label=s)
for s, c in components.items():
    g = np.linspace(c["mx"] - 2.58 * np.sqrt(c["vx"]), c["mx"] + 2.58 * np.sqrt(c["vx"]), 130)
    m = c["a"] + c["b"] * g
    axes[1].plot(g, m, color=COLORS[s], label=f"Компонент {s}")
    axes[1].fill_between(g, m - 1.96 * c["sigma"], m + 1.96 * c["sigma"], color=COLORS[s], alpha=.15)
axes[1].plot(grid, mixture_prediction(grid), color=GREEN, ls="--", label="Средний прогноз по длине")
axes[0].set_title("Общая и две прямые с известным видом")
axes[1].set_title("EM: две регрессии без меток вида")
axes[0].legend(fontsize=8); axes[1].legend(fontsize=8)
maes = [results["penguin_test"][n]["mae"] for n in predictions]
bars = axes[2].bar(range(3), maes, color=[RED, BLUE, GREEN])
axes[2].bar_label(bars, fmt="%.2f", padding=3)
axes[2].set(xticks=range(3), xticklabels=["Одна\nпрямая", "Две, вид\nизвестен", "Смесь, вид\nскрыт"], title=f"MAE на одном тесте (n={len(p_test)})", ylabel="Ошибка глубины, мм", ylim=(0, max(maes) * 1.25))
figure(fig, "04_penguins_two_regressions.png")

# %% [markdown]
# **Одна прямая смешивает группы:** общий наклон на обучении -0.202, хотя внутри каждого вида наклоны положительны. Это пример изменения знака связи при объединении разных групп, а не отрицательная связь внутри вида.
#
# На обучении остаточные SD Adelie и Gentoo равны 1.170 и 0.758 мм. Диагностический тест Левена по остаткам: p=0.00025; он согласуется с различием разбросов, при этом остатки сами оценены по данным.
#
# На одном тесте из 83 пингвинов MAE:
#
# - Одна прямая: **1.397 мм**, RMSE 1.651 мм.
# - Две, вид известен: **0.732 мм**, RMSE 0.905 мм.
# - Смесь, вид скрыт: **1.024 мм**, RMSE 1.310 мм.
#
# **Уравнения, найденные EM без меток вида:**
#
# - Полоса Adelie: $d\mid L,k\sim N(12.423+0.152L,\ 1.175^2)$.
# - Полоса Gentoo: $d\mid L,k\sim N(5.177+0.206L,\ 0.677^2)$.
#
# Для EM полоса ±1,96σ показывает оценённый внутригрупповой шум, без
# неопределённости параметров; у регрессий с известным видом показан t-интервал
# с учётом параметров. Поэтому ширину этих полос нельзя сравнивать как
# одинаково точные доверительные интервалы. Две прямые с известным видом —
# ориентир при дополнительной информации; смесь на тесте этой информации не имеет.

# %% [markdown]
# ### 1.4. «Подходит первому, второму, обоим или ни одному»
#
# Для известных групп объект совместим с регрессией, если глубина внутри
# 95% прогнозного интервала и длина внутри обучающего диапазона вида.
# Для EM используем |d−a_k−b_k L| ≤ 1,96σ_k и
# (L−μ_L,k)²/v_L,k ≤ χ²(1;0,99): ограничиваем также область по длине.
# У EM это приближённое правило совместимости, а не калиброванная вероятность
# принадлежности виду. Отклонение по двум критериям не имеет ровно 5% уровня.
# Обе модели могут вернуть неоднозначность или отказ. Метки Chinstrap никогда
# не используются для обучения или настройки границ.

# %%
# Области совместимости и проверка третьего вида

def compatible(x, y, method):
    x, y = np.asarray(x), np.asarray(y)
    accepted = []
    for s in ["Adelie", "Gentoo"]:
        if method == "supervised":
            lo, hi = interval(separate[s], x, observation=True)
            p = p_train.loc[p_train.species.eq(s), "bill_length_mm"]
            inside = (x >= p.min()) & (x <= p.max()) & (y >= lo) & (y <= hi)
        else:
            c = components[s]
            inside = ((x - c["mx"])**2 / c["vx"] <= chi2.ppf(.99, 1)) & (np.abs(y - c["a"] - c["b"] * x) <= 1.96 * c["sigma"])
        accepted.append(inside)
    return accepted[0].astype(int) + 2 * accepted[1].astype(int)


xx, yy = np.meshgrid(np.linspace(30, 62, 300), np.linspace(11.5, 23, 240))
region_colors = ["#E8EAED", "#C0D9EF", "#F1D4B2", "#D6C4E4"]
fig, axes = plt.subplots(1, 3, figsize=(16, 4.7), layout="constrained", gridspec_kw={"width_ratios": [1, 1, 1.1]})
for ax, method, title in zip(axes[:2], ["supervised", "em"], ["Две регрессии: вид известен при обучении", "Две регрессии EM: вид скрыт при обучении"]):
    regions = compatible(xx.ravel(), yy.ravel(), method).reshape(xx.shape)
    ax.pcolormesh(xx, yy, regions, cmap=ListedColormap(region_colors), vmin=0, vmax=3, shading="auto", rasterized=True)
    for s, part in pd.concat([p_test, p_other]).groupby("species"):
        ax.scatter(part.bill_length_mm, part.bill_depth_mm, color=COLORS[s], marker="x" if s == "Chinstrap" else "o", s=18, alpha=.65, label=s)
    ax.set(title=title, xlabel="Длина клюва, мм", ylabel="Глубина клюва, мм", xlim=(30, 62), ylim=(11.5, 23))
    ax.legend(fontsize=7, loc="upper left")
# Четыре исхода по фактическим видам; только тест известных видов плюс весь третий вид.
evaluation = pd.concat([p_test, p_other])
decisions = compatible(evaluation.bill_length_mm, evaluation.bill_depth_mm, "em")
decision_counts = pd.crosstab(evaluation.species.to_numpy(), decisions).reindex(index=species_order, columns=range(4), fill_value=0)
decision_rates = decision_counts.div(decision_counts.sum(axis=1), axis=0)
bottom = np.zeros(3)
for j, name in enumerate(["Ни одному", "Только Adelie", "Только Gentoo", "Обоим"]):
    axes[2].bar(species_order, decision_rates[j] * 100, bottom=bottom, color=region_colors[j], edgecolor="white", label=name)
    bottom += decision_rates[j].to_numpy() * 100
axes[2].set(title="Ответы EM на отложенных объектах", ylabel="Доля объектов, %", ylim=(0, 100))
axes[2].legend(fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.12), ncol=2)
figure(fig, "05_penguins_compatibility.png")
results["penguin_decisions"] = {s: decision_counts.loc[s].tolist() for s in species_order}

# %% [markdown]
# **Проверка правила EM.** Из 83 тестовых Adelie/Gentoo однозначно принят правильной полосой 78, отклонено 5. Из 68 Chinstrap отклонено 57 (83.8%), остальные 11 совместимы с одной из известных полос. Здесь не возникло ответов «обоим», но правило сохраняет такую возможность при пересечении областей. Отказ и ошибка класса учитываются отдельно.
#
# **Пригодность первого датасета.** Набор подходит: две отдельные регрессии
# имеют разный разброс, а правило допускает отказ и неоднозначность. Одна
# прямая усредняет разные группы. Чужой вид частично пересекается с известными,
# поэтому стопроцентное отвержение Chinstrap по двум размерам недостижимо.
# Для задачи множественной регрессии дополнительно доступны три геометрических
# признака массы. Корреляция и правила совместимости не доказывают биологическую
# принадлежность нового пингвина и не заменяют внешнюю проверку на других колониях.

# %% [markdown]
# ## 2. Abalone: нелинейная зависимость полной массы от размера
#
# [UCI Abalone](https://archive.ics.uci.edu/dataset/1/abalone) содержит 4177
# наблюдений морских ушек: пол/категория I, три размера, полная масса, массы
# частей и кольца. Исходная цель UCI — возраст; здесь **цель переопределена**
# как полная масса W. Rings не используем как целевую переменную.
# Значения оставляем в опубликованном масштабе файла: формулы ниже относятся
# именно к нему, единицы автоматически не пересчитываем.
#
# Геометрическая гипотеза: W ≈ aL^b; при сходной форме объём и масса растут
# примерно как куб линейного размера. Логарифм даёт ln W = ln a + b ln L + ε.
# Показатель b оцениваем, а не фиксируем равным трём.

# %%
# Качество Abalone и единое разбиение
columns = ["sex", "length", "diameter", "height", "whole_weight", "shucked_weight", "viscera_weight", "shell_weight", "rings"]
a_raw = pd.read_csv(BASE / "data/abalone.data", names=columns)
assert not a_raw.isna().any().any() and not a_raw.duplicated().any()
positive = a_raw[["length", "diameter", "height", "whole_weight"]].gt(0).all(axis=1)
abalone = a_raw.loc[positive].copy()
a_train, a_test = train_test_split(abalone, test_size=.25, random_state=SEED)
assert set(a_train.index).isdisjoint(a_test.index)
fig, axes = plt.subplots(1, 3, figsize=(13, 3.8), layout="constrained")
axes[0].hist(a_raw.length, bins=30, color=BLUE, alpha=.8)
axes[0].set(title="Длина: диапазон и плотность", xlabel="L, ед. файла", ylabel="Наблюдений")
axes[1].scatter(a_raw.length, a_raw.height, s=9, alpha=.25, color=BLUE)
flags = a_raw.height.le(0) | a_raw.height.gt(a_raw.length)
axes[1].scatter(a_raw.loc[flags, "length"], a_raw.loc[flags, "height"], color=RED, marker="x", s=65, label="Нулевые/аномальные высоты")
axes[1].set(title="Высота: кандидаты на проверку", xlabel="L, ед. файла", ylabel="H, ед. файла")
axes[1].legend(fontsize=7)
axes[2].hist(a_raw.whole_weight, bins=35, color=GREEN, alpha=.8)
axes[2].set(title="Полная масса", xlabel="W, ед. файла", ylabel="Наблюдений")
figure(fig, "06_abalone_quality.png")
results["abalone_counts"] = {"raw": len(a_raw), "nonpositive": int((~positive).sum()), "train": len(a_train), "test": len(a_test)}

# %% [markdown]
# Два наблюдения с нулевой высотой исключены до общего разбиения, потому
# что логарифм высоты не определён. Это правило области определения, а не
# удаление по величине ошибки. Аномальная высота 1,13 пока сохранена:
# статистический выброс не объявляем доказанной ошибкой измерения.
# Все дальнейшие сравнения используют одни и те же отложенные строки.

# %%
# Модели массы: преобразования, дополнительные признаки и очистка
specifications = {
    "Линейная L": (["length"], False, False),
    "Линейная L,D,H": (["length", "diameter", "height"], False, False),
    "Степенная L": (["length"], True, False),
    "Степенная L,D,H": (["length", "diameter", "height"], True, False),
    "L,D,H + пол": (["length", "diameter", "height"], True, True),
    "L,D,H + пол + кольца": (["length", "diameter", "height", "rings"], True, True),
    "L,D,H + массы частей": (["length", "diameter", "height", "shucked_weight", "viscera_weight", "shell_weight"], True, False),
}


def abalone_x(frame, specification):
    names, logged, sex = specifications[specification]
    values = frame[names].to_numpy(dtype=float)
    if logged:
        values = np.log(values)
    if sex:
        values = np.column_stack([values, frame.sex.eq("F"), frame.sex.eq("I")])
    return values


def fit_abalone(frame, specification):
    logged = specifications[specification][1]
    y = np.log(frame.whole_weight) if logged else frame.whole_weight
    fit = ols(abalone_x(frame, specification), y)
    # Поправка smearing оценивается только по обучающим остаткам.
    fit["smear"] = float(np.exp(fit["error"]).mean()) if logged else 1.
    fit["spec"] = specification
    return fit


def predict_mass(fit, frame, mean=True):
    value = predict(fit, abalone_x(frame, fit["spec"]))
    if specifications[fit["spec"]][1]:
        return np.exp(value) * (fit["smear"] if mean else 1.)
    return value


def clean_training(frame):
    # Робастные правила оцениваются заново на каждом обучающем фолде.
    initial = fit_abalone(frame, "Степенная L")
    e = initial["error"]
    center = np.median(e)
    scale = max(1.4826 * np.median(np.abs(e - center)), 1e-9)
    ratio = np.log(frame.height / frame.length).to_numpy()
    ratio_center = np.median(ratio)
    ratio_scale = max(1.4826 * np.median(np.abs(ratio - ratio_center)), 1e-9)
    bad_residual = np.abs(e - center) > 3.5 * scale
    bad_geometry = (np.abs(ratio - ratio_center) > 4.5 * ratio_scale) | frame.height.gt(frame.length).to_numpy()
    keep = ~(bad_residual | bad_geometry)
    return frame.loc[keep], {"removed": int((~keep).sum()), "residual": int(bad_residual.sum()), "geometry": int(bad_geometry.sum())}


clean_train, clean_stats = clean_training(a_train)
results["cleaning"] = clean_stats
raw_fits = {name: fit_abalone(a_train, name) for name in specifications}
clean_fits = {name: fit_abalone(clean_train, name) for name in specifications}
linear_fit = raw_fits["Линейная L"]
power_fit = raw_fits["Степенная L"]
length_grid = np.linspace(a_train.length.min(), a_train.length.max(), 250)
grid_frame = pd.DataFrame({"length": length_grid})
log_lo, log_hi = interval(power_fit, np.log(length_grid))
fig, axes = plt.subplots(2, 2, figsize=(12, 8), layout="constrained")
axes[0, 0].scatter(a_train.length, a_train.whole_weight, s=8, alpha=.15, color=BLUE)
axes[0, 0].plot(length_grid, predict_mass(linear_fit, grid_frame), color=RED, label="Линейная W ~ L")
axes[0, 0].plot(length_grid, predict_mass(power_fit, grid_frame), color=GREEN, label="Степенная: средняя масса")
axes[0, 0].fill_between(length_grid, np.exp(log_lo) * power_fit["smear"], np.exp(log_hi) * power_fit["smear"], color=GREEN, alpha=.25)
axes[0, 0].set(title="Исходные оси: прямая и степенная кривая", xlabel="L", ylabel="W")
axes[0, 0].legend(fontsize=8)
axes[0, 1].scatter(np.log(a_train.length), np.log(a_train.whole_weight), s=8, alpha=.18, color=BLUE)
axes[0, 1].plot(np.log(length_grid), predict(power_fit, np.log(length_grid)), color=GREEN)
axes[0, 1].fill_between(np.log(length_grid), log_lo, log_hi, color=GREEN, alpha=.25)
axes[0, 1].set(title="Логарифмы: линейная модель и 95% ДИ", xlabel="ln L", ylabel="ln W")
axes[1, 0].scatter(a_train.length, linear_fit["error"], color=RED, s=8, alpha=.2)
axes[1, 0].set(title="Остатки обычной прямой: систематический изгиб", xlabel="L", ylabel="W − прогноз")
axes[1, 1].scatter(np.log(a_train.length), power_fit["error"], color=GREEN, s=8, alpha=.2)
axes[1, 1].set(title="Остатки логарифмической модели", xlabel="ln L", ylabel="ln W − прогноз")
for ax in axes[1]: ax.axhline(0, color=".4", lw=1)
for ax in axes.ravel(): ax.grid()
figure(fig, "07_abalone_linearization.png")
results["power_raw"] = {"beta": power_fit["beta"].tolist(), "ci": coefficient_ci(power_fit).tolist(), "smear": power_fit["smear"], "sigma": np.sqrt(power_fit["mse"])}

# %% [markdown]
# **До очистки:** $\ln W=1.6214+3.0425\ln L+\varepsilon$, то есть геометрическое среднее $W\approx 5.0601L^{3.0425}$. 95% ДИ показателя степени: [3.0214; 3.0637], он далеко от 1; зависимость близка к кубической, но b не фиксировано равным 3. Поправка среднего smearing=1.01002.
#
# На одинаковом тесте MAE обычной прямой 0.1396, степенной модели 0.0879; $R^2$ растёт с 0.852 до 0.931. Это подтверждает пользу преобразования и вне обучения.
#
# **Почему зависимость нелинейна.** В исходных координатах у обычной прямой
# остаётся изгиб остатков, тогда как ln W от ln L ближе к прямой. Проверяем
# это также ошибкой на одинаковых отложенных объектах. Преобразование осей
# само по себе не является доказательством качества прогноза.
# exp(a+b ln L) описывает геометрическое среднее, а при симметричном шуме
# логарифмов — медиану W|L. Для прогноза арифметической средней массы
# умножаем на smearing = mean(exp(ε)) обучающей выборки. При выраженной
# неодинаковой дисперсии логарифмов такая общая поправка лишь приближённая.

# %% [markdown]
# ### 2.1. Помогают ли остальные параметры?
#
# Сравниваем модели на пяти фолдах обучения и на одном фиксированном тесте.
# В каждом фолде все коэффициенты и smearing оцениваются заново. Здесь пока
# нет очистки статистических выбросов, чтобы выделить эффект признаков.
# По тестовым строкам bootstrap оценивает 95% ДИ **парной разности MAE**
# при последовательном добавлении признаков. Положительная разность
# MAE(база)−MAE(расширенная) означает улучшение; это четыре отдельных исследовательских
# сравнения, без заявления об одновременном 95% уровне.

# %%
# Сравнение признаков: CV и парные разности ошибок на тесте
folds = KFold(n_splits=5, shuffle=True, random_state=SEED)
cv_errors = {name: [] for name in specifications}
for tr, va in folds.split(a_train):
    for name in specifications:
        fitted = fit_abalone(a_train.iloc[tr], name)
        cv_errors[name].append(mean_absolute_error(a_train.iloc[va].whole_weight, predict_mass(fitted, a_train.iloc[va])))
test_errors = {}
for name, fit in raw_fits.items():
    pred = predict_mass(fit, a_test)
    test_errors[name] = np.abs(a_test.whole_weight.to_numpy() - pred)
    results.setdefault("abalone_scores", {})[name] = {
        "mae": test_errors[name].mean(), "rmse": np.sqrt(np.mean((a_test.whole_weight.to_numpy() - pred)**2)),
        "r2": r2_score(a_test.whole_weight, pred), "cv_mae": np.mean(cv_errors[name]),
    }
fig, axes = plt.subplots(1, 2, figsize=(15, 5), layout="constrained", gridspec_kw={"width_ratios": [1.25, 1]})
positions = np.arange(len(specifications))
for j, name in enumerate(specifications):
    axes[0].scatter(cv_errors[name], j + np.linspace(-.12, .12, 5), color=BLUE, s=18, label="Пять CV-фолдов" if j == 0 else None)
    axes[0].scatter(test_errors[name].mean(), j, color=RED, marker="D", s=35, label="Один тест" if j == 0 else None)
axes[0].set(yticks=positions, yticklabels=list(specifications), xlabel="MAE массы, ед. файла", title="Одни и те же фолды и тестовые строки")
axes[0].invert_yaxis(); axes[0].legend(fontsize=8); axes[0].grid(axis="x")
feature_comparisons = [
    ("Степенная L", "Степенная L,D,H"),
    ("Степенная L,D,H", "L,D,H + пол"),
    ("L,D,H + пол", "L,D,H + пол + кольца"),
    ("Степенная L,D,H", "L,D,H + массы частей"),
]
rng = np.random.default_rng(SEED)
indices = rng.integers(0, len(a_test), size=(2000, len(a_test)))
paired = {}
for j, (baseline, name) in enumerate(feature_comparisons):
    difference = test_errors[baseline] - test_errors[name]
    low, high = np.quantile(difference[indices].mean(axis=1), [.025, .975])
    paired[name] = {"baseline": baseline, "delta": difference.mean(), "lo": low, "hi": high}
    axes[1].hlines(j, low, high, color=GREEN, lw=3)
    axes[1].scatter(difference.mean(), j, color=GREEN)
axes[1].axvline(0, color=".4", ls="--")
axes[1].set(yticks=range(4), yticklabels=["Добавить D,H к L", "Добавить пол к L,D,H", "Добавить кольца к размерам и полу", "Массы частей к L,D,H"], xlabel="Уменьшение MAE при добавлении признаков", title="Парные 95% ДИ улучшения на тесте")
axes[1].invert_yaxis(); axes[1].grid(axis="x")
figure(fig, "08_abalone_extra_features.png")
results["paired_improvement"] = paired

# %% [markdown]
# **Проверка вместо предположения о бесполезности признаков.** Добавление диаметра и высоты уменьшает тестовую MAE с 0.0879 до 0.0759; 95% ДИ улучшения [0.0090; 0.0151] исключает ноль. Пол даёт ещё небольшое улучшение: [0.0008; 0.0028]. Поэтому утверждение «остальные параметры не помогают» для этого набора неверно.
#
# **Пример признака без убедительного добавочного выигрыша:** кольца после размеров и пола уменьшают MAE лишь на 0.00018, 95% ДИ [-0.00032; 0.00069] содержит ноль. Это отсутствие установленного улучшения на данном тесте, а не доказанная бесполезность колец вообще. Массы частей дают MAE 0.0277, но требуют другой доступной информации.
#
# Массы мяса, внутренностей и раковины особенно информативны, потому что
# относятся к частям той же полной массы. Это другая практическая постановка:
# для прогноза массы неповреждённого объекта они обычно недоступны заранее.
# Кольца тоже требуют отдельного измерения. Эти признаки не скрываем, но
# отделяем их от прогноза только по внешним размерам. Дополнительные размеры
# могут помогать и при пригодности длины для демонстрации линеаризации.

# %% [markdown]
# ### 2.2. Очистка выбросов: сравнение без подмены теста
#
# На обучении отмечаем: остаток ln W ~ ln L дальше 3,5 робастных SD от медианы;
# ln(H/L) дальше 4,5 робастных SD; H > L. Робастное SD = 1,4826×MAD.
# Пороги выбраны как диагностическое правило, а не по минимальной ошибке теста.
# Кандидаты могут быть настоящими необычными животными: очистка — анализ
# чувствительности. На тесте не удаляем строки по их массе или ошибке.
#
# Чтобы сравнение CV было честным, внутри каждого фолда пороги очистки
# вычисляются только на его обучающей части. Доверительные интервалы после
# очистки условны относительно выбранных строк и не учитывают неопределённость
# самого решения об удалении. HC3 оценивает неопределённость среднего профиля;
# прогнозный интервал дополнительно предполагает одинаковый нормальный шум в ln W.

# %%
# Очистка: кривые, интервалы и контрольная ошибка
before, after = power_fit, clean_fits["Степенная L"]
central_lo, central_hi = clean_train.length.quantile([.025, .975])
common_grid = np.linspace(a_train.length.min(), a_train.length.max(), 250)
fig, axes = plt.subplots(2, 2, figsize=(13, 8), layout="constrained")
removed = a_train.loc[~a_train.index.isin(clean_train.index)]
axes[0, 0].scatter(a_train.length, a_train.whole_weight, color=".6", s=8, alpha=.18)
axes[0, 0].scatter(removed.length, removed.whole_weight, color=RED, marker="x", s=28, label=f"Кандидаты на удаление: {len(removed)}")
for fit, frame, color, label in [(before, a_train, BLUE, "До очистки"), (after, clean_train, ORANGE, "После очистки")]:
    gx = pd.DataFrame({"length": common_grid})
    lo, hi = interval(fit, np.log(common_grid))
    mean = predict_mass(fit, gx)
    axes[0, 0].plot(common_grid, mean, color=color, label=label)
    axes[0, 0].fill_between(common_grid, np.exp(lo) * fit["smear"], np.exp(hi) * fit["smear"], color=color, alpha=.22)
    axes[0, 1].plot(np.log(common_grid), predict(fit, np.log(common_grid)), color=color, label=label)
    axes[0, 1].fill_between(np.log(common_grid), lo, hi, color=color, alpha=.2)
    axes[1, 0].plot(common_grid, (np.exp(hi) - np.exp(lo)) * fit["smear"], color=color, label=label)
axes[0, 1].scatter(np.log(a_train.length), np.log(a_train.whole_weight), color=".6", s=7, alpha=.15)
axes[0, 0].set(title="Степенная кривая и 95% ДИ до/после", xlabel="L", ylabel="Средняя W")
axes[0, 1].set(title="Те же регрессии в логарифмах и 95% ДИ", xlabel="ln L", ylabel="ln W")
axes[1, 0].set(title="Ширина 95% ДИ среднего в исходном масштабе", xlabel="L", ylabel="Верхняя − нижняя граница")
clean_cv = {name: [] for name in ["Степенная L", "Степенная L,D,H"]}
for tr, va in folds.split(a_train):
    fold_clean, _ = clean_training(a_train.iloc[tr])
    for name in clean_cv:
        fit = fit_abalone(fold_clean, name)
        clean_cv[name].append(mean_absolute_error(a_train.iloc[va].whole_weight, predict_mass(fit, a_train.iloc[va])))
for j, name in enumerate(clean_cv):
    values = [results["abalone_scores"][name]["mae"], mean_absolute_error(a_test.whole_weight, predict_mass(clean_fits[name], a_test))]
    axes[1, 1].bar(np.array([0, 1]) + j * .30, values, width=.28, color=[BLUE, ORANGE], alpha=1 if j == 0 else .55, label=name)
    for x, value in zip(np.array([0, 1]) + j * .30, values):
        axes[1, 1].annotate(f"{value:.4f}", (x, value), xytext=(0, 4), textcoords="offset points", ha="center", fontsize=8)
    results.setdefault("clean_scores", {})[name] = {"mae": values[1], "cv_mae": np.mean(clean_cv[name]), "cv_before": np.mean(cv_errors[name])}
    delta = test_errors[name] - np.abs(a_test.whole_weight.to_numpy() - predict_mass(clean_fits[name], a_test))
    results["clean_scores"][name]["delta_ci"] = np.quantile(delta[indices].mean(axis=1), [.025, .975]).tolist()
axes[1, 1].set(xticks=[.15, 1.15], xticklabels=["До очистки", "После очистки"], title="MAE на неизменном тесте", ylabel="MAE массы", ylim=(0, .12))
for ax in axes.ravel(): ax.grid(); ax.legend(fontsize=8)
figure(fig, "09_abalone_cleaning.png")
results["power_clean"] = {"beta": after["beta"].tolist(), "ci": coefficient_ci(after).tolist(), "smear": after["smear"], "sigma": np.sqrt(after["mse"])}

# %% [markdown]
# **Результат очистки:** из 3131 обучающих строк отмечено 38 (27 по остаткам, 11 по геометрии; считаем объединение). У показателя b оценка меняется с 3.0425 до 3.0532; 95% ДИ после очистки [3.0359; 3.0705]. При L=0,5 ширина 95% ДИ среднего W уменьшается с 0.00613 до 0.00556.
#
# MAE степенной модели одной длины на прежнем тесте: 0.08791 → 0.08774, 95% ДИ уменьшения ошибки [-0.00003; 0.00038] включает ноль. Для трёх размеров: 0.07592 → 0.07573. Убедительного тестового выигрыша очистка не показала. CV также меняется мало: для одной длины 0.08559 → 0.08534.
#
# Интервалы и коэффициенты действительно меняются после очистки, но меньшая
# ширина ДИ ещё не доказывает улучшение. Критерий пользы — ошибка на прежних
# тестовых объектах, в том числе необычных. Удаление хвостов может искусственно
# сузить интервал и ухудшить охват новых наблюдений.

# %% [markdown]
# ### 2.3. Уравнение, область использования и прогнозный интервал
#
# Показываем простую степенную модель после очистки, пригодную для объяснения
# преобразования. Для практического прогноза несколькими размерами можно
# пользоваться многомерной моделью из сравнения. Рекомендуемая область
# простой формулы — центральные 95% обучающих длин: это правило достаточной
# плотности данных, а не доказанная физическая граница. На краях данных мало;
# за наблюдаемым диапазоном неопределённость экстраполяции этими ДИ не описана.

# %%
# Область применимости и отличие доверительного от прогнозного интервала
fig, axes = plt.subplots(1, 2, figsize=(13, 4.6), layout="constrained", gridspec_kw={"width_ratios": [1.5, 1]})
lo, hi = interval(after, np.log(common_grid))
plo, phi = interval(after, np.log(common_grid), observation=True)
grid_frame = pd.DataFrame({"length": common_grid})
axes[0].fill_between(common_grid, np.exp(plo), np.exp(phi), color=BLUE, alpha=.12, label="95% прогнозный интервал W")
axes[0].fill_between(common_grid, np.exp(lo) * after["smear"], np.exp(hi) * after["smear"], color=ORANGE, alpha=.5, label="95% ДИ средней W (условный)")
axes[0].plot(common_grid, predict_mass(after, grid_frame), color=ORANGE, label="Средняя W: smearing")
axes[0].scatter(a_test.length, a_test.whole_weight, s=8, alpha=.16, color=BLUE, label="Неизменный тест")
for ax in axes:
    ax.axvspan(common_grid.min(), central_lo, color=".6", alpha=.18)
    ax.axvspan(central_hi, common_grid.max(), color=".6", alpha=.18)
    ax.axvline(central_lo, color=".4", ls=":"); ax.axvline(central_hi, color=".4", ls=":")
    ax.grid()
axes[0].set(title="Серые края: мало данных; за ними не экстраполируем", xlabel="L, ед. файла", ylabel="W, ед. файла")
axes[0].legend(fontsize=7, loc="upper left")
axes[1].hist(clean_train.length, bins=25, color=BLUE, alpha=.7)
axes[1].set(title=f"Центральные 95% длин: [{central_lo:.3f}; {central_hi:.3f}]", xlabel="L, ед. файла", ylabel="Обучающих наблюдений")
figure(fig, "10_abalone_domain_intervals.png")
interval_scores = {}
for label, fit in [("before", before), ("after", after)]:
    low, high = interval(fit, np.log(a_test.length), observation=True)
    inside = (np.log(a_test.whole_weight) >= low) & (np.log(a_test.whole_weight) <= high)
    mean_low, mean_high = interval(fit, np.log([.5]))
    interval_scores[label] = {
        "coverage": inside.mean(), "width": np.mean(np.exp(high) - np.exp(low)),
        "mean_ci_width_at_0.5": float((np.exp(mean_high[0]) - np.exp(mean_low[0])) * fit["smear"]),
    }
results["interval_scores"] = interval_scores
results["length_domain"] = {"observed": [a_train.length.min(), a_train.length.max()], "central": [central_lo, central_hi]}
results["geometry_equation"] = {"beta": clean_fits["Степенная L,D,H"]["beta"].tolist(), "smear": clean_fits["Степенная L,D,H"]["smear"]}

# %% [markdown]
# **Формула после очистки** в масштабе CSV:
#
# $$\widehat{W}_{geom}=5.0786L^{3.0532},\qquad \widehat{E[W\mid L]}\approx 5.1200L^{3.0532}.$$
#
# Первое выражение — геометрическое среднее (медиана при симметричном логарифмическом шуме), второе учитывает smearing. Для отдельных объектов в логарифмах:
#
# $$\ln W_{new}(L)\approx 1.6250+3.0532\ln L\ \pm\ t_{n-2;0.975}\,0.1271\sqrt{1+h(L)},$$
#
# где $h(L)=1/n+(\ln L-\overline{\ln L})^2/\sum_i(\ln L_i-\overline{\ln L})^2$; обе границы затем экспоненцируются.
#
# Рекомендуемая центральная область L ∈ **[0.260; 0.715]**, полный наблюдаемый обучающий диапазон [0.075; 0.815]. Для формулы трёх размеров после очистки:
#
# $$\widehat{E[W\mid L,D,H]}\approx 10.4643L^{1.5928}D^{0.9436}H^{0.4096}.$$
#
# Последнюю формулу применяем только для положительных размеров в области совместной поддержки обучения; один допустимый диапазон L не гарантирует допустимость любых сочетаний D,H.
#
# **Проверка интервалов на 1044 неизменных тестовых строках:** до очистки охват 94.9%, после — 93.5%; средняя ширина прогнозного интервала 0.449 → 0.409. Более узкий интервал после удаления необычных объектов хуже покрывает исходный тест.
#
# Номинальные 95% прогнозные интервалы требуют проверки: фактический охват
# теста указан выше, его не подгоняли до 95%. Интервал среднего значительно
# уже интервала отдельного животного, потому что не включает весь естественный
# разброс массы. После очистки охват нужно проверять на исходном тесте.
# В интервале средней W неопределённость smearing отдельно не учтена;
# поэтому он условный и приближённый. Точнее оценить его можно bootstrap
# с повторной оценкой поправки и процедуры очистки.

# %% [markdown]
# ## 3. Итог выбора датасетов
#
# **Palmer Penguins оставляем:** в задаче двух регрессий есть две полосы,
# разный разброс и проверяемое правило отказа; третий вид показывает
# ограничение распознавания неизвестных объектов. Для массы имеются
# несколько геометрических предикторов. Случайность связи клюва у какого-то
# вида этими данными не подтверждается — не подменяем этим желаемым выводом результат.
#
# **Abalone оставляем:** степенная связь линеаризуется логарифмом, её можно
# сравнить с исходной прямой по остаткам и контрольной ошибке. Остальные размеры
# помогают прогнозу; это не мешает использовать одну длину для задания на
# линеаризацию. Если требование состоит именно в бесполезности любых других
# признаков, Abalone ему не соответствует. Для заявленной задачи нелинейности
# такой дополнительный критерий не нужен.
#
# Оба набора учебные и описательные: найденные связи не устанавливают
# причинность. Все численные выводы относятся к локальным файлам, фиксированному
# разбиению и приведённым правилам очистки. Повторные запуски при тех же
# версиях библиотек воспроизводят расчёты; текст Markdown содержит результаты
# этого фиксированного запуска и при смене данных должен быть обновлён.

# %%
# Сохранение численных результатов для проверки отчёта

def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.generic):
        return value.item()
    return value


_ = (OUT / "analysis_results.json").write_text(json.dumps(plain(results), ensure_ascii=False, indent=2))
